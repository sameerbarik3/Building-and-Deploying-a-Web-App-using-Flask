from . import mathematics
from Maths.mathematics import summation, subtraction, multiplication